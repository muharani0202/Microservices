<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;

Route::get('/', function () {
    return view('welcome');
});

// Endpoint Health Check di web.php
Route::get('/health', [OrderController::class, 'health']);